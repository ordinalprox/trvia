score=0
correct=0

q1= input('how many continents are there in the world?\n').lower()
if q1=="7":
    score=score+10
    correct=correct+1
elif q1=="7":
    score=score+10
    correct=correct+1
else:
    if score > 0:
     score=score-10

q2= input("what continent is russia in\n").lower()
if q2=="Asia":
    score=score+10
    correct=correct+1
elif q2=="Europe":
    score=score+10
    correct=correct+1
else:
    if score > 0:
     score=score-10

q3= input("what continent is belarus in\n").lower()
if q3=="Europe":
    score=score+10
    correct=correct+1
else:
    if score >10:
     score=score-10

q4= input("how many major desert are there in the world?\n").lower()
if q4=="33":
    score=score+10
    correct=correct+1
else:
    if score >10:
     score=score-10

q5= input("Which is the world's deepest ocean trench?\n").lower()
if q5=="Mariana Trench":
    score=score+10
    correct=correct+1
else:
    if score >10:
     score=score-10

q6=input("Which country has the longest coastline in the world?\n").lower()
if q6=="Canada":
    score=score+10
    correct=correct+1
else:
    if score >10:
     score=score-10

q7=input("What are the five oceans of the world?\n").lower()
if q7=="Pacific, Atlantic, Indian, Southern, Arctic":
    score=score+20
    correct=correct+1
else:
    if score >10:
     score=score-10
q8=input("Which is the largest island in the world?\n").lower()
if q8=="Greenland":
    score=score+10
    correct=correct+1
else:
    if score >10:
     score=score-10

q9=input("Which is the world's largest desert?\n").lower()
if q9=="Antarctic Desert":
    score=score+10
    correct=correct+1
else:
    if score >10:
     score=score-10

q10=input("What is the name of the only sea without a land boundary?\n").lower()
if q10=="Sargasso Sea":
    score=score+10
    correct=correct+1
else:
    if score >10:
     score=score-10

print(score,correct)

